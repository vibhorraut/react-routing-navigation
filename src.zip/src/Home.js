import React from 'react';
import ImageSlider from './ImageSlider';

const Home = () => {
  return (
    <div>
      <h1>Home Page</h1>
      <p>Welcome to the Home page!</p>
      <p>
        Discover the latest trends and updates with our exclusive content and
        features. Our platform offers a wide range of articles, guides, and
        resources to help you stay informed and engaged. Explore now and be
        part of our community!
      </p>
      <ImageSlider />
    </div>
  );
}

export default Home;