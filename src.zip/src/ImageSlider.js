import React from 'react';
import Slider from 'react-slick';
import './ImageSlider.css'; // Optional: for custom styling

const ImageSlider = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };

  return (
    <div className="image-slider">
      <Slider {...settings}>
        <div>
          <img src="https://shapedplugin.com/wp-content/uploads/2023/03/Best-banner-slider-WordPress-plugins-blog-feature-image-800x400.png" alt="Slide 1" />
        </div>
        <div>
          <img src="https://img.freepik.com/free-psd/minimal-furniture-facebook-cover-page-template_237398-161.jpg" alt="Slide 2" />
        </div>
        <div>
          <img src="https://via.placeholder.com/800x400" alt="Slide 3" />
        </div>
      </Slider>
    </div>
  );
};

export default ImageSlider;